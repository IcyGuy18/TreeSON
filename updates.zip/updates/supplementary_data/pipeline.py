from __future__ import annotations
import zipfile, json
from pathlib import Path
from typing import Dict, List, Literal, Optional
import requests, numpy as np, pandas as pd
from bs4 import BeautifulSoup
from functools import lru_cache
from requests.adapters import HTTPAdapter, Retry
from pymongo import MongoClient, ASCENDING, UpdateOne
from collections import defaultdict
from itertools import islice

BASE_URL = 'https://biomics.lab.nycu.edu.tw/dbPTM'
DATA_DIR = Path('dbptm_data')
AA = list("ACDEFGHIKLMNPQRSTVWY")
POS = [f"{i:+d}" for i in range(-10, 11)]

def make_session() -> requests.Session:
    s = requests.Session()
    retries = Retry(
        total=5, connect=5, read=5,
        backoff_factor=0.5,
        status_forcelist=(429, 500, 502, 503, 504),
        allowed_methods=frozenset(['GET'])
    )
    s.mount('http://', HTTPAdapter(max_retries=retries))
    s.mount('https://', HTTPAdapter(max_retries=retries))
    s.headers.update({'User-Agent': 'ptmkb/1.0'})
    return s

SESSION = make_session()

def construct_subsequence(protein: str, site0: int, flank: int = 10) -> str:
    start = max(0, site0 - flank)
    end = min(len(protein), site0 + flank + 1)
    subseq = protein[start:end]
    if site0 < flank:
        subseq = ('-' * (flank - site0)) + subseq
    if site0 + flank >= len(protein):  # fix: >=
        subseq += '-' * ((site0 + flank + 1) - len(protein))
    return subseq

@lru_cache(maxsize=100_000)
def resolve_sequence(accession: str) -> Optional[str]:
    if not accession or not isinstance(accession, str):
        return None

    r = SESSION.get(
        f'http://www.ebi.ac.uk/proteins/api/proteins/{accession}',
        timeout=20
    )
    if r.ok:
        try:
            return r.json()['sequence']['sequence']
        except Exception:
            pass

    r = SESSION.get(
        f'https://rest.uniprot.org/uniprotkb/{accession}',
        headers={'Accept':'application/json'},
        timeout=20
    )
    if r.ok:
        try:
            js = r.json()
            if 'inactiveReason' not in js:
                return js['sequence']['value']

            reason = js['inactiveReason'].get('inactiveReasonType')
            if reason == 'DELETED':
                upid = js['extraAttributes']['uniParcId']
                r2 = SESSION.get(
                    f'https://rest.uniprot.org/uniparc/{upid}',
                    headers={'Accept':'application/json'},
                    timeout=20
                )
                if r2.ok:
                    return r2.json()['sequence']['value']
            elif reason == 'DEMERGED':
                new_acc = js['inactiveReason']['mergeDemergeTo'][0]
                r2 = SESSION.get(
                    f'https://rest.uniprot.org/uniprotkb/{new_acc}',
                    headers={'Accept':'application/json'},
                    timeout=20
                )
                if r2.ok:
                    return r2.json()['sequence']['value']
        except Exception:
            pass

    return None

def resolve_accession(protein_id: str) -> Optional[str]:
    if not protein_id or not isinstance(protein_id, str):
        return None

    r = SESSION.get(
        f'http://www.ebi.ac.uk/proteins/api/proteins/{protein_id}',
        timeout=20
    )
    if r.ok:
        try:
            js = r.json()
            acc = js.get('accession') or js.get('id') or None
            if acc:
                return acc
        except Exception:
            pass

    r = SESSION.get(
        f'https://rest.uniprot.org/uniprotkb/{protein_id}',
        headers={'Accept': 'application/json'},
        timeout=20
    )
    if r.ok:
        try:
            js = r.json()
            acc = js.get('primaryAccession')
            if acc:
                return acc

            inactive = js.get('inactiveReason')
            if inactive:
                reason = inactive.get('inactiveReasonType')
                if reason == 'DEMERGED':
                    targets = inactive.get('mergeDemergeTo') or []
                    if targets:
                        new_acc = targets[0]
                        r2 = SESSION.get(
                            f'https://rest.uniprot.org/uniprotkb/{new_acc}',
                            headers={'Accept': 'application/json'},
                            timeout=20
                        )
                        if r2.ok:
                            return r2.json().get('primaryAccession')
                elif reason == 'DELETED':
                    uni_parc_id = js.get('extraAttributes', {}).get('uniParcId')
                    if uni_parc_id:
                        r2 = SESSION.get(
                            f'https://rest.uniprot.org/uniparc/{uni_parc_id}',
                            headers={'Accept': 'application/json'},
                            timeout=20
                        )
                        if r2.ok:
                            up_json = r2.json()
                            xrefs = up_json.get('uniParcCrossReferences') or []
                            if xrefs:
                                return xrefs[0].get('id')
        except Exception:
            pass

    return None

def download_and_extract() -> List[Path]:
    DATA_DIR.mkdir(exist_ok=True)
    zips = []
    resp = SESSION.get(f'{BASE_URL}/download.php', timeout=30)
    resp.raise_for_status()
    soup = BeautifulSoup(resp.text, 'html.parser')
    for a in soup.find_all('a', href=True):
        href = a['href']
        if 'experiment' in href and href.endswith('.zip'):
            url = f"{BASE_URL}/{href}"
            fn = DATA_DIR / url.split('/')[-1]
            if not fn.exists():
                with SESSION.get(url, stream=True, timeout=60) as r:
                    r.raise_for_status()
                    with open(fn, 'wb') as f:
                        for chunk in r.iter_content(1<<14):
                            if chunk: f.write(chunk)
            zips.append(fn)

    # extract
    tsvs = []
    for z in zips:
        with zipfile.ZipFile(z, 'r') as zf:
            zf.extractall(DATA_DIR)
            for n in zf.namelist():
                if '.' not in n:
                    tsvs.append(DATA_DIR / n)
    return tsvs

def load_ptm_file(path: Path) -> pd.DataFrame:
    df = pd.read_csv(
        path, sep='\t', header=None,
        names=['ProID','Acc#','ModSite','PTM','EvdId','Seq'],
        dtype={'ProID':str,'Acc#':str,'ModSite':int,'PTM':str,'EvdId':str,'Seq':str},
        na_values=['','NA','NaN']
    )
    return df

def fill_windows(df: pd.DataFrame) -> pd.DataFrame:
    missing = df['Seq'].isna() | (df['Seq'].str.len() != 21)
    need = df.loc[missing, 'Acc#'].dropna().unique().tolist()

    acc2seq: Dict[str, Optional[str]] = {acc: resolve_sequence(acc) for acc in need}

    out = df.copy()
    rows = out.loc[missing]
    for idx, row in rows.iterrows():
        acc = row['Acc#']
        site = int(row['ModSite'])
        seq = acc2seq.get(acc)
        subseq = construct_subsequence(seq, site-1) if seq else None
        out.at[idx, 'Seq'] = subseq

    out = out[out['Seq'].notna() & (out['Seq'].str.len() == 21)]
    out['Seq'] = out['Seq'].str.upper()
    return out

def compute_pfms(
    df: pd.DataFrame,
    methods: List[Literal['freq','log-e','log2','log10']] = ['freq']
) -> Dict[str, Dict[str, Dict[str, Dict[str, float]]]]:
    df = df.copy()
    df = df[df['Seq'].notna() & (df['Seq'].str.len() == 21)]
    counts: Dict[str, Dict[str, Dict[str, int]]] = defaultdict(
        lambda: {pos: {aa: 0 for aa in AA} for pos in POS}
    )

    for seq in df['Seq'].astype(str):
        mid = seq[10]
        if mid not in AA:
            continue
        for j, ch in enumerate(seq):
            if ch in AA:
                counts[mid][POS[j]][ch] += 1

    pfms: Dict[str, Dict[str, Dict[str, Dict[str, float]]]] = {m: {} for m in methods}
    pc = 0.5
    for mid, posmap in counts.items():
        freq_map: Dict[str, Dict[str, float]] = {}
        for pos, row in posmap.items():
            total = sum(row.values())
            denom = total + pc * len(AA)
            freq_map[pos] = {aa: (row[aa] + pc) / denom for aa in AA}
        if 'freq' in methods:
            pfms['freq'][mid] = freq_map
        for method in methods:
            if method == 'freq':
                continue
            trans = {}
            if method == 'log-e':
                for pos, row in freq_map.items():
                    trans[pos] = {aa: float(np.log(v)) for aa, v in row.items()}
            elif method == 'log2':
                for pos, row in freq_map.items():
                    trans[pos] = {aa: float(np.log2(v)) for aa, v in row.items()}
            elif method == 'log10':
                for pos, row in freq_map.items():
                    trans[pos] = {aa: float(np.log10(v)) for aa, v in row.items()}
            pfms[method][mid] = trans

    return pfms

def fill_missing_accessions(df: pd.DataFrame) -> pd.DataFrame:
    out = df.copy()
    mask = out['Acc#'].isna() | (out['Acc#'].astype(str).str.strip() == "")
    pro_ids = out.loc[mask, 'ProID'].dropna().unique().tolist()

    if not pro_ids:
        return out

    acc_map = {}
    for pid in pro_ids:
        acc = resolve_accession(pid)
        if acc:
            acc_map[pid] = acc

    for pid, acc in acc_map.items():
        out.loc[mask & (out['ProID'] == pid), 'Acc#'] = acc

    return out

def connect_mongo(uri="mongodb://localhost:27017", db_name="ptmkb2"):
    client = MongoClient(uri, timeoutMS=120000)
    db = client[db_name]
    tables = db['tables']
    proteins = db['proteins']
    tables.create_index([('ptm', ASCENDING)], unique=True)
    proteins.create_index([('Protein Identifier', ASCENDING), ('Accession Number', ASCENDING)], unique=True)
    proteins.create_index([('Accession Number', ASCENDING)], unique=False)
    return tables, proteins

# --------- BUILD OPS (no writes here) ---------

def build_matrices_ops(ptm_name: str, pfm_doc: Dict) -> UpdateOne:
    # upsert one doc per PTM name
    return UpdateOne(
        {'ptm': ptm_name},
        {'$set': {'data': pfm_doc}},
        upsert=True
    )

def build_protein_ops(df: pd.DataFrame) -> List[UpdateOne]:
    df2 = df[df['Acc#'].notna()].copy()
    if df2.empty:
        return []
    ops: List[UpdateOne] = []
    for (proid, acc), group in df2.groupby(['ProID', 'Acc#']):
        ptm_rows = []
        for _, r in group.iterrows():
            evids = "" if pd.isna(r['EvdId']) else str(r['EvdId'])
            ptm_rows.append([int(r['ModSite']), str(r['PTM']), evids])

        ops.append(UpdateOne(
            {"Protein Identifier": str(proid), "Accession Number": str(acc)},
            {
                "$setOnInsert": {
                    "Protein Identifier": str(proid),
                    "Accession Number": str(acc),
                },
                "$addToSet": {"PTMs": {"$each": ptm_rows}}
            },
            upsert=True
        ))
    return ops

# --------- PROCESS FILE -> return ops ---------

def process_file_build_ops(path: Path, emit_json=False):
    df = load_ptm_file(path)

    print("\tFilling missing accessions...")
    df = fill_missing_accessions(df)
    print("\tFilling missing sequences...")
    df = fill_windows(df)

    print("\tComputing positional frequency matrices...")
    mongo_doc = compute_pfms(df, methods=['freq','log-e'])

    if emit_json:
        outdir = Path('tables') / path.stem
        outdir.mkdir(parents=True, exist_ok=True)
        for method, mids in mongo_doc.items():
            (outdir / method).mkdir(exist_ok=True)
            for mid_res, posmap in mids.items():
                with open(outdir / method / f'{mid_res}.json', 'w') as f:
                    json.dump(posmap, f, indent=2)

    ptm_name = str(df['PTM'].iloc[0]) if len(df) else path.stem
    table_op = build_matrices_ops(ptm_name, mongo_doc)
    protein_ops = build_protein_ops(df)
    return table_op, protein_ops

# --------- RUN (one bulk_write per collection) ---------

def chunked(iterable, n):
    it = iter(iterable)
    while True:
        batch = list(islice(it, n))
        if not batch:
            return
        yield batch

def write_all_in_one_go(db, stage_proteins_docs, stage_tables_docs,
                        protein_chunk=50_000, table_chunk=10_000):
    proteins = db['proteins']
    tables   = db['tables']
    p_stage  = db['proteins_stage']
    t_stage  = db['tables_stage']

    # fresh staging
    p_stage.drop()
    t_stage.drop()

    # 1) insert_many into staging (chunked)
    if stage_proteins_docs:
        for batch in chunked(stage_proteins_docs, protein_chunk):
            p_stage.insert_many(batch, ordered=False)

    if stage_tables_docs:
        for batch in chunked(stage_tables_docs, table_chunk):
            t_stage.insert_many(batch, ordered=False)

    # 2) one $merge for proteins: union PTMs across existing + new
    db.command({
        "aggregate": "proteins_stage",
        "pipeline": [
            # normalize PTMs in staged docs (make sure array exists)
            {"$project": {
                "Protein Identifier": 1,
                "Accession Number": 1,
                "PTMs": {"$ifNull": ["$PTMs", []]}
            }},
            # ensure duplicates inside the staged doc are deduped
            {"$project": {
                "Protein Identifier": 1,
                "Accession Number": 1,
                "PTMs": {"$setUnion": ["$PTMs", []]}
            }},
            {"$merge": {
                "into": "proteins",
                "on": ["Protein Identifier", "Accession Number"],
                "whenMatched": [
                    {"$set": {
                        # $$ROOT is the current target doc; $$new is the staged doc
                        "PTMs": {"$setUnion": ["$$ROOT.PTMs", "$$new.PTMs"]}
                    }}
                ],
                "whenNotMatched": "insert"
            }}
        ],
        "cursor": {}
    })

    # 3) one $merge for tables: replace data by ptm
    db.command({
        "aggregate": "tables_stage",
        "pipeline": [
            {"$project": {"ptm": 1, "data": 1}},
            {"$merge": {
                "into": "tables",
                "on": "ptm",
                "whenMatched": "replace",
                "whenNotMatched": "insert"
            }}
        ],
        "cursor": {}
    })

    # optional cleanup
    p_stage.drop()
    t_stage.drop()

def run_pipeline():
    print("Downloading files...")
    tsvs = download_and_extract()

    print("Connecting to MongoDB...")
    client = MongoClient("mongodb://localhost:27017", timeoutMS=120000)
    db = client["ptmkb2"]

    # ensure indexes once
    db['tables'].create_index([('ptm', ASCENDING)], unique=True)
    db['proteins'].create_index(
        [('Protein Identifier', ASCENDING), ('Accession Number', ASCENDING)],
        unique=True
    )
    db['proteins'].create_index([('Accession Number', ASCENDING)], unique=False)

    stage_proteins = {}  # key: (ProID, Acc#) -> set of PTM triplets
    stage_tables   = {}  # key: ptm_name -> pfm_doc (last write wins)

    print(f"Processing following files: {[i.name.split('/')[-1] for i in tsvs]}")
    for p in tsvs:
        if not p.exists():
            continue
        print(80 * "-")
        print(f"Loading {p.name.split('/')[-1]}...")
        print(80 * "-")

        df = load_ptm_file(p)
        print("\tFilling missing accessions...")
        df = fill_missing_accessions(df)
        print("\tFilling missing sequences...")
        df = fill_windows(df)

        # accumulate proteins (dedupe in memory)
        for (proid, acc), group in df[df['Acc#'].notna()].groupby(['ProID','Acc#']):
            key = (str(proid), str(acc))
            bucket = stage_proteins.setdefault(key, set())
            for _, r in group.iterrows():
                evids = "" if pd.isna(r['EvdId']) else str(r['EvdId'])
                # normalize evidence order so set semantics work
                if evids:
                    parts = sorted([s for s in evids.split(';') if s])
                    evids = ';'.join(parts)
                bucket.add((int(r['ModSite']), str(r['PTM']), evids))

        # accumulate tables (replace per-PTM)
        ptm_name = str(df['PTM'].iloc[0]) if len(df) else p.stem
        print("\tComputing positional frequency matrices...")
        pfm = compute_pfms(df, methods=['freq','log-e'])
        stage_tables[ptm_name] = pfm

        print("Done!\n")

    # convert accumulators into lists of docs for staging
    stage_proteins_docs = [{
        "Protein Identifier": k[0],
        "Accession Number": k[1],
        "PTMs": [list(t) for t in sorted(v)]
    } for k, v in stage_proteins.items()]

    stage_tables_docs = [{
        "ptm": ptm,
        "data": doc
    } for ptm, doc in stage_tables.items()]

    print(f"Staging {len(stage_proteins_docs)} proteins; {len(stage_tables_docs)} tables...")
    write_all_in_one_go(db, stage_proteins_docs, stage_tables_docs)
    print("All done.")

if __name__ == "__main__":
    run_pipeline()
